import java.io.*;

public class MyQueue implements IMyQueue {
	public MyQueue ()
	{
		front=0;
		rear=0;
		maxQue=0;
		items = new int [MAXSIZE];
	}

	public MyQueue(int max)
	{
	   maxQue = max+1;
 	   front = maxQue - 1;
	   rear = maxQue - 1;
       items = new int [max];
	}
	
	public boolean isFull ()
	{
	   // WRAP AROUND
	   return ( (rear + 1) % maxQue == front );
	}
	
	public boolean isEmpty ()
	{
	   return ( rear == front );
	}
	
	public void enqueue (int item)
	{
	   if (!isFull())
	   {  rear = (rear+1) % maxQue;
          items[rear] = item;
	   }
	   else
	      System.out.println ("Tried to insert into full stack.");
	}
	
	public int dequeue ()
	{
	  int item = 0;
	  if (!isEmpty()) 
	  {  front = (front+1) % maxQue;
         item = items[front];
	  }
	  else
	     System.out.println ("Tried to remove from empty stack.");
		 
	  return item;
	}
	
	public final int MAXSIZE =100;
	private int front;
	private int rear;
	private int maxQue;
	private int items [];
}
