
public interface IMyQueue
{
	/** 
	 * Returns true iff MyQueue is full
	 * @param none
	 * @return boolean
	 */
	public boolean isFull ();
	
/** 
	 * Returns true iff MyQueue is empty
	 * @param none
	 * @return boolean
	 */
	public boolean isEmpty ();
	
	/**
	 * Inserts an element at the rear of the MyQueue
	 * @param item, the item to be inserted
	 */
	public void enqueue (int item);
	
	/**
	 * Returns (and removes) an element from the MyQueue
	 * @param item, the item that is removed/returned
	 */
	public int dequeue ();
}
