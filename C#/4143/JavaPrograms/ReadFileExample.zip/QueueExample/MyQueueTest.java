import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 * This program tests the MyQueue class
 * @version 1.0 2013-08-29
 * @author Catherine Stringfellow
 */

public class MyQueueTest 
{
	public static void main(String[] args) 
	{
		int item;
		MyQueue myQueue;
		PrintWriter out;
		Scanner in;
		String s;

		//Declare and open output file
		try
		{
			//asks user to enter name of output file and open output file
			in = new Scanner(System.in);
		    System.out.print ("Enter the name of an output file ");			
			s = in.nextLine();
			out = new PrintWriter(new FileWriter(s));
			
			//print headings
			Headings(out);	
			
			//put things in the MyQueue
			myQueue = GetInput();	
			
			//print the MyQueue
			PrintQueue (out, myQueue);
		
			//Calls method to output the end
			//of the table
			Closing(out);
			out.close();
		}
		catch (IOException e)
		{
			System.out.println("There was an error creating the output file.");
		}
	}
	
	/**
	 * Collects various input by the user (input file, integers for queue)
	 */ 
	public static MyQueue GetInput()
	{
	    MyQueue myQueue;
		
		try
		{		
			//Reads in the name of the input file the user wishes to use
			String inFile = JOptionPane.showInputDialog("Please "
				+ "enter the input file. If nothing is entered, "
				+ " the default input file will be used: 'QData.dat'\n");
			
			//Uses QData.dat as default input 
			//file if another was not entered
			if (inFile.length()==0)
				inFile = "QData.dat";
			
			//Declares a BufferedReader for input from files
			BufferedReader in = new BufferedReader(new
				FileReader(inFile));
			
			//Read in items from a file
			myQueue = ReadData (in);
			in.close();

			return myQueue;
		}
		catch(IOException exception)
		{
			System.out.println("There was an error in reading "
				+ " the file.");
			return null;
		}	
	}	

	/**
	 * Returns MyQueue data
	 * @param in, a buffered reader
	 * @return a MyQueue of data
	 * @throws IOException
	 */
	public static MyQueue ReadData (BufferedReader in)
		throws IOException
		{
			String s;
			MyQueue myQueue;
			
			//get number of items in file and instantiate myQueue
			s = in.readLine();
			int numItems = Integer.parseInt(s);
			myQueue = new MyQueue (numItems);
				
			//fill up my MyQueue
			while ((s = in.readLine()) != null)
			{
			    //way to get multiple items on a line
				StringTokenizer t = new StringTokenizer(s);
				int item = Integer.parseInt(t.nextToken());
				myQueue.enqueue(item);
			}
			
			return myQueue;
		}
	
	/**Writes output data
	 * @param out, output stream
	 * @param myQueue, MyQueue of ints
	 */
	public static void PrintQueue(PrintWriter out, MyQueue myQueue)
	{
		while (!myQueue.isEmpty())
		{
		   int item = myQueue.dequeue();
		   out.println(item + " ");
		}
	}
	
	/**
	 * Writes heading
	 */
	public static void Headings(PrintWriter out)
	{
		//Outputs introductory message to screen
		System.out.println();
	    System.out.println("**********Welcome to the MyQueueTest program!**********");
		System.out.println();
		System.out.println("This program reads data into a MyQueue and prints it out");
		System.out.println();	
		
		//Outputs Heading to file
		out.println();
		out.println("**********Data in the Queue!**********");
		out.println(); 
	}
	
	/**
	 * Writes the closing message
	 */
	public static void Closing(PrintWriter out)
	{
		//Outputs the ending message to console and file
		out.println("***************Thanks for using MyQueueTest!***************");
		out.close();

		System.out.println();
		System.out.println("**********Thanks for using MyQueueTest!**********");
		System.out.println();		
	}

}