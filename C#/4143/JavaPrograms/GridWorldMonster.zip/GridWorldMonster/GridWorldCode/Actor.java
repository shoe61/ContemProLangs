﻿/**
 * An actor is anything that can exist in the world
 */
 public class Actor
    {
        private String name;

        public Actor()
        {
            name = "Actor";
        }

        public String GetImage()
        {
            return name;
        }
/*
        /**
        * Gets the color of this actor.
        * @return the color of this actor
        /
        public Color getColor()
        {

        }

        /**
         * Sets the color of this actor.
         * @param newColor the new color
         /
        public void setColor(Color newColor)
        {

        }

        /**
         * Gets the current direction of this actor.
         * @return the direction of this actor, an angle between 0 and 359 degrees
         /
        public int getDirection()
        {

        }

        /**
         * Sets the current direction of this actor.
         * @param newDirection the new direction. The direction of this actor is set
         * to the angle between 0 and 359 degrees that is equivalent to
         * newDirection.
         /
        public void setDirection(int newDirection)
        {

        }

        /**
         * Gets the location of this actor. 
         * Precondition: This actor is contained in a grid
         * @return the location of this actor
         /
        public Location getLocation()
        {

        }

        /**
         * Puts this actor into a grid. If there is another actor at the given
         * location, it is removed. 
         * Precondition: (1) This actor is not contained in a grid (2)
         * loc is valid in gr
         * @param gr the grid into which this actor should be placed
         * @param loc the location into which the actor should be placed
         /
        public void putSelfInGrid(Grid<Actor> gr, Location loc)
        {

        }

        /**
         * Removes this actor from its grid. 
         * Precondition: This actor is contained in a grid
         /
        public void removeSelfFromGrid()
        {

        }

        /**
         * Moves this actor to a new location. If there is another actor at the
         * given location, it is removed. 
         * Precondition: (1) This actor is contained in a grid (2)
         * newLocation is valid in the grid of this actor
         * @param newLocation the new location
         /
        public void moveTo(Location newLocation)
        {

        }

        /**
         * Reverses the direction of this actor. Override this method in subclasses
         * of Actor to define types of actors with different behavior
         * 
         /
        public void act()
        {

        }

        /**
         * Creates a string that describes this actor.
         * @return a string with the location, direction, and color of this actor
         /
        public String toString()
        {

        }
*/
    }

