
/**
 * A Rock is an actor that does nothing. It is commonly used to
 * block other actors from moving. 

 */

public class Rock extends Actor
{
    
    

    /**
     * Constructs a black rock.
     */
    public Rock()
    {
       
    }

    /**
     * Constructs a rock of a given color.
     * @param rockColor the color of this rock
     */
    public Rock(Color rockColor)
    {
        
    }

    /**
     * Overrides the act method in the Actor class
     * to do nothing.
     */
    public void act()
    {
    }
}
