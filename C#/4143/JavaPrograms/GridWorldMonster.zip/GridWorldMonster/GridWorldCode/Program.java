﻿import java.util.*;
import java.collections.*;/**
 * This program...
 */


    class Program
    {
        static void Main(String[] args)
        {
            ActorWorld world = new ActorWorld();
            world.add(new Monster());
            world.add(new Rock());
            world.show();
        }
    }
